# DIAI — GitHub Codespaces용 재구축 프로젝트

## 포함된 기능
- 기존 DIAI HTML 화면과 모바일 하단 메뉴
- 검정 다크 테마
- 캐릭터 탐색, 랭킹/글로벌 플롯, 플롯 만들기, 대화 목록, 프로필
- 서버의 `/api/chat`를 통한 OpenAI API 연결
- `/api/health` 상태 확인
- API 키는 서버 환경변수로만 읽음

## 휴대폰 Codespaces에서 실행하기
1. GitHub에서 기존 DIAI 저장소를 열고 Codespaces를 실행합니다.
2. 저장소의 `index.html`을 이 폴더의 `index.html` 내용으로 교체합니다.
3. `server.js`, `package.json`, `.gitignore` 파일을 저장소 최상위에 추가합니다.
4. 터미널에서 `npm install`을 실행합니다.
5. GitHub 저장소의 **Settings → Secrets and variables → Codespaces**에서 `OPENAI_API_KEY`를 추가합니다. 실제 키를 HTML이나 채팅 메시지에 붙여 넣지 마세요.
6. Codespace를 재시작한 뒤 터미널에서 `npm start`를 실행합니다.
7. **Ports** 탭에서 포트 `3000`을 확인하고 브라우저 아이콘 또는 공개 링크로 엽니다. 공개(Visibility) 설정은 필요한 경우에만 바꾸세요.
8. `/api/health`를 열어 `aiConfigured: true`인지 확인합니다.

## 중요
- API 사용에는 별도 OpenAI API 키와 결제/사용량 한도가 필요할 수 있습니다.
- 기존 화면의 회원가입은 현재 데모용이며 실제 계정 인증이 아닙니다. 프로덕션 전에 Supabase Auth 등 인증 서비스와 데이터베이스를 연결해야 합니다.
- 캐릭터, 스토리, 채팅은 기존 브라우저 저장 방식을 유지하므로 다른 기기와 자동 동기화되지 않습니다.
- 배포 전에는 로그인, 권한 검사, 요청 제한(rate limiting), 개인정보 처리방침, 신고/차단 기능을 추가하세요.
- 제타의 소스 코드나 독점 자산을 복제하지 않고 DIAI 고유의 디자인을 사용합니다.
